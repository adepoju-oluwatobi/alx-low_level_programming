Singly linked list tasks
