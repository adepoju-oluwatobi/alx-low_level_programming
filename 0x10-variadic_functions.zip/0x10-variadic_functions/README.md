Variadic function
